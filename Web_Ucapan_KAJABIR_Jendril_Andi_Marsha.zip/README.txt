WEB UCAPAN TO KAJABIR — Jendril ANDI MARSHA

Cara pakai:
1. Buka index.html di browser.
2. Dua gambar sudah ada di folder assets.
3. Untuk musik Tulus, masukkan file audio yang kamu punya sendiri ke:
   assets/tulus.mp3
4. Buka lagi index.html lalu tekan tombol ♫.

Catatan:
- Website dibuat responsive untuk HP dan laptop.
- Musik tidak disertakan karena file musiknya belum diberikan.
- Kamu bebas mengganti teks, gambar, dan musik di folder assets.
